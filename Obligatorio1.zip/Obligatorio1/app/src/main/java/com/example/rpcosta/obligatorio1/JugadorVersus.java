package com.example.rpcosta.obligatorio1;

import AsyncTask.BuscarJugador;
import AsyncTask.CrearDesafio;
import DataBase.BaseDatos;
import Interfaces.BuscarJugadorInterface;
import Interfaces.CrearDesafioInterface;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;


public class JugadorVersus extends Activity implements BuscarJugadorInterface, CrearDesafioInterface {
    private EditText buscar;
    private Button btnBuscar;
    private ListView lista;
    private BaseDatos bd;
    private Boolean yaDesafiado;
    private SharedPreferences prefs;
    private Desafios desafio;
    private ProgressDialog dialogo = null;
    private ArrayList<Desafios> listaDesafios;
    private ArrayList<Jugador> listaVersus;
    private static String TIPO_RANDOM = "random";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jugador_versus);
        buscar = (EditText) findViewById(R.id.editText3);
        btnBuscar = (Button) findViewById(R.id.button5);
        desafio = new Desafios();
        prefs = getSharedPreferences("MisPreferencias", Context.MODE_PRIVATE);
        lista = (ListView) findViewById(R.id.listView);
        bd = new BaseDatos(this);
        listaDesafios = bd.listaDesafios();
        listaVersus = new ArrayList<Jugador>();
        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (buscar.getText().toString().isEmpty()) {
                    Toast msj = Toast.makeText(JugadorVersus.this, getResources().getString(R.string.mensajeErrorEmpty), Toast.LENGTH_SHORT);
                    msj.show();
                } else {
                    new BuscarJugador(JugadorVersus.this).execute(buscar.getText().toString());
                }
            }
        });
        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int contarDesafios = 0;
                yaDesafiado = false;
                for (int i = 0; i < listaDesafios.size() && !yaDesafiado; i++) {
                    if (listaDesafios.get(i).getStatus().equalsIgnoreCase("pending")) {
                        contarDesafios += 1;
                    }
                    if ((listaDesafios.get(i).getStatus().equalsIgnoreCase("pending")) && (listaDesafios.get(i).getId_user1().equalsIgnoreCase(listaVersus.get(position).getId()) || listaDesafios.get(i).getId_user2().equalsIgnoreCase(listaVersus.get(position).getId()))) {
                        yaDesafiado = true;
                    }
                }
                if (yaDesafiado) {
                    Toast msj = Toast.makeText(JugadorVersus.this, R.string.already_chalenged, Toast.LENGTH_SHORT);
                    msj.show();
                } else {
                    if (contarDesafios < 5) {
                        dialogo = ProgressDialog.show(JugadorVersus.this, "",getResources().getString(R.string.desafiando), true);
                        ArrayList<String> lista = new ArrayList<String>();
                        lista.add(prefs.getString("id", null));
                        lista.add(listaVersus.get(position).getId());
                        new CrearDesafio(JugadorVersus.this).execute(lista);
                        
                    } else {
                        Toast msj = Toast.makeText(JugadorVersus.this, R.string.limite_desafio, Toast.LENGTH_SHORT);
                        msj.show();
                    }
                }
            }
        });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_jugador_versus, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void buscarJugador(ArrayList<Jugador> listaJugadores) {

        if (listaJugadores != null) {
            listaVersus = listaJugadores;
            AdapterListSearch adapter = new AdapterListSearch(JugadorVersus.this, R.id.listView, listaVersus);
            lista.setAdapter(adapter);
            adapter.notifyDataSetChanged();


        }


    }

    @Override
    public void crearDesafio(Desafios challenge) {
        dialogo.dismiss();
        desafio = challenge;
        desafio.setMail("");
        desafio.setName("");
        desafio.setUrl("");
        bd.insertarDesafios(desafio);
        Intent i = new Intent(JugadorVersus.this, DesafioIndividual.class);
        i.putExtra("tipo", TIPO_RANDOM);
        i.putExtra("ids", prefs.getString("id", null));
        i.putExtra("versus", "versus");
        i.putExtra("idChallenge", desafio.getId());
        i.putExtra("desafio",desafio);
        startActivity(i);
    }
}
