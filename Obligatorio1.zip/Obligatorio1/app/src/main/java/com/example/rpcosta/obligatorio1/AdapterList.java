package com.example.rpcosta.obligatorio1;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


/**
 * Created by rpcosta on 13/10/14.
 */
public class AdapterList extends ArrayAdapter<Desafios> {

    Context actividad;
    private ArrayList<Desafios> lista;
    private LayoutInflater inflater;


    public AdapterList(Context context, int resc, ArrayList<Desafios> objects) {
        super(context, resc, objects);
        lista = objects;
        actividad = context;
        inflater = LayoutInflater.from(context);

    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.activity_list, parent, false);
            holder.title = (TextView) convertView.findViewById(R.id.textView17);
            holder.foto = (ImageView) convertView.findViewById(R.id.imageView14);
            holder.mail = (TextView) convertView.findViewById(R.id.textView18);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();

        }
        holder.title.setText("Jugador: " + lista.get(position).getName());
        if (!lista.get(position).getUrl().equalsIgnoreCase("")) {
            Picasso.with(actividad).load(lista.get(position).getUrl()).into(holder.foto);
        }
        holder.mail.setText(lista.get(position).getMail());
        return convertView;

    }

    static class ViewHolder {
        TextView title, mail;
        ImageView foto;
    }


}
