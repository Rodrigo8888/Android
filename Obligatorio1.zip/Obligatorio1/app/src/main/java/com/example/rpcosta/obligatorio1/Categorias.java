package com.example.rpcosta.obligatorio1;

/**
 * Created by rpcosta on 7/12/14.
 */
public class Categorias {
    String nombre;
    String id;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
