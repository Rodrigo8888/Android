package com.example.rpcosta.obligatorio1;

import java.util.ArrayList;

/**
 * Created by rpcosta on 7/11/14.
 */
public class EstructuraPreguntas {
    String preguntas;
    ArrayList<String> opciones;
    String idPregunta;
    ArrayList<String> idOption;

    public ArrayList<String> getIdOption() {
        return idOption;
    }

    public void setIdOption(ArrayList<String> idOption) {
        this.idOption = idOption;
    }

    public String getPreguntas() {
        return preguntas;
    }

    public void setPreguntas(String preguntas) {
        this.preguntas = preguntas;
    }

    public ArrayList<String> getOpciones() {
        return opciones;
    }

    public void setOpciones(ArrayList<String> opciones) {
        this.opciones = opciones;
    }

    public String getIdPregunta() {
        return idPregunta;
    }

    public void setIdPregunta(String idPregunta) {
        this.idPregunta = idPregunta;
    }
}
