package com.example.rpcosta.obligatorio1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.example.rpcosta.obligatorio1.Services.MyService;

/**
 * Created by rpcosta on 15/12/14.
 */
public class MyReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        context.startService(new Intent(context, MyService.class));
    }
}