package com.example.rpcosta.obligatorio1.Services;

import AsyncTask.ObtenerDesafio;
import DataBase.BaseDatos;
import Interfaces.Desafio;
import android.app.IntentService;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import com.example.rpcosta.obligatorio1.*;

import java.util.ArrayList;

/**
 * Created by rpcosta on 27/10/14.
 */
public class MyService extends IntentService implements Desafio {
    private BaseDatos db;
    private Handler handler;
    private ArrayList<Desafios> listaDesafios;
    private SharedPreferences prefs;
    private Boolean primeraVez;
    private static String VERSUS_CHALLENGE = "versus";


    public MyService() {
        super("MyService");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        db = new BaseDatos(this);
        prefs = getSharedPreferences("MisPreferencias", Context.MODE_PRIVATE);

    }

    private void checkear() {
        primeraVez = false;
        ArrayList<Desafios> lista = db.listaDesafios();
        ArrayList<Desafios> listaCorrecta = new ArrayList<Desafios>();
        for (int k = lista.size() - 1; k >= 0; k--) {
            listaCorrecta.add(lista.get(k));
        }
        if(listaCorrecta.size()>0){
            lista = listaCorrecta;
        }
        //Comprobar desafíos
        for (int i = 0; i < lista.size(); i++) {
            for (int j = 0; j < listaDesafios.size(); j++) {
                if (lista.get(i).getId().equalsIgnoreCase(listaDesafios.get(j).getId())) {
                    if ((!lista.get(i).getStatus().equalsIgnoreCase(listaDesafios.get(j).getStatus())) && listaDesafios.get(j).getStatus().equalsIgnoreCase("finished")) {
                        lista.get(i).setStatus("finished");
                        lista.get(i).setWinner(listaDesafios.get(j).getWinner());
                        db.insertarPreguntasDesafio(listaDesafios.get(j));
                        String resultado;
                        db.insertarDesafios(lista.get(i));
                        if (listaDesafios.get(j).getWinner().equalsIgnoreCase("0")) {
                            resultado = getResources().getString(R.string.draw);
                        } else {
                            if (listaDesafios.get(j).getWinner().equalsIgnoreCase(prefs.getString("id", null))) {
                                resultado = getResources().getString(R.string.win);
                            } else {
                                resultado = getResources().getString(R.string.loose);
                            }
                        }
                        Intent inte = new Intent(MyService.this, MiPerfil.class);
                        PendingIntent pIntent = PendingIntent.getActivity(this, listaDesafios.get(j).getId().hashCode(), inte, PendingIntent.FLAG_ONE_SHOT);
                        Notification n = new Notification.Builder(this)
                                .setContentTitle(resultado + " " + listaDesafios.get(j).getName())
                                .setSmallIcon(R.drawable.cerebrote3)
                                .setContentIntent(pIntent)
                                .setAutoCancel(true).build();
                        NotificationManager notificationManager =
                                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                        notificationManager.notify(listaDesafios.get(j).getId().hashCode(), n);
                        n.defaults |= Notification.DEFAULT_LIGHTS;

                    }
                }
            }
        }
        if (lista.size() <= listaDesafios.size()) {
            if (lista.size() == 0 && listaDesafios.size() != 0) {
                for (int j = 0; j < listaDesafios.size(); j++) {
                    db.insertarDesafios(listaDesafios.get(j));
                    db.insertarPreguntasDesafio(listaDesafios.get(j));
                }
                primeraVez = true;
            }
            for (int i = 0; i < lista.size(); i++) {
                ArrayList<Questions> listaPreguntas = db.obtenerPreguntas(lista.get(i));
                lista.get(i).setQuestions(listaPreguntas);
            }
            //Recorrer y verificar estados pendientes con finalizados para saber si gané o perdí etc
            if (lista.size() < listaDesafios.size()) {
                //Desafíos nuevos
                Boolean nuevo = false;
                int posicion=0;
                for(int i = 0; i<listaDesafios.size()&&!nuevo;i++){
                    for(int j = 0; j<lista.size();j++){
                        if(!listaDesafios.get(i).getId().equalsIgnoreCase(lista.get(j).getId())){
                            nuevo = true;
                        }
                    }
                    if(nuevo){
                          posicion = i;
                    }
                }
                Intent inte = new Intent(MyService.this, VentanaDesafios.class);
                inte.putExtra("versus", VERSUS_CHALLENGE);
                inte.putExtra("ids", prefs.getString("id", null));
                inte.putExtra("idChallenge", listaDesafios.get(posicion).getId());
                PendingIntent pIntent = PendingIntent.getActivity(this, listaDesafios.get(posicion).getId().hashCode(), inte, PendingIntent.FLAG_ONE_SHOT);
                Notification n = new Notification.Builder(this)
                        .setContentTitle(getResources().getString(R.string.nuevo_desafio))
                        .setSmallIcon(R.drawable.cerebrote3)
                        .setContentIntent(pIntent)
                        .setAutoCancel(true).build();
                NotificationManager notificationManager =
                        (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                notificationManager.notify(listaDesafios.get(posicion).getId().hashCode(), n);
                n.defaults |= Notification.DEFAULT_LIGHTS;

                //Guardar en base de datos
                if (!primeraVez) {
                    for (int i = 0; i < listaDesafios.size(); i++) {
                        db.insertarDesafios(listaDesafios.get(i));
                        db.insertarPreguntasDesafio(listaDesafios.get(i));
                    }
                }

            } else {
                //Verificar desafíos en juego y guardan en BD y WService
                for (int j = 0; j < lista.size(); j++) {
                    if (lista.get(j).getQuestions().size() < listaDesafios.get(j).getQuestions().size() && !listaDesafios.get(j).getStatus().equalsIgnoreCase("finished")) {
                        //Juego yo
                        Intent inte = new Intent(MyService.this, VentanaDesafios.class);
                        inte.putExtra("versus", VERSUS_CHALLENGE);
                        inte.putExtra("ids", prefs.getString("id", null));
                        inte.putExtra("idChallenge", lista.get(j).getId());
                        PendingIntent pIntent = PendingIntent.getActivity(this, lista.get(j).getId().hashCode(), inte, PendingIntent.FLAG_ONE_SHOT);
                        Notification n = new Notification.Builder(this)
                                .setContentTitle(getResources().getString(R.string.turn))
                                .setSmallIcon(R.drawable.cerebrote3)
                                .setContentIntent(pIntent)
                                .setAutoCancel(true).build();
                        NotificationManager notificationManager =
                                (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                        notificationManager.notify(lista.get(j).getId().hashCode(), n);
                        n.defaults |= Notification.DEFAULT_LIGHTS;

                        //Guardar en base de datos
                        lista.get(j).setQuestions(listaDesafios.get(j).getQuestions());
                        db.insertarPreguntasDesafio(lista.get(j));
                    }

                }

            }
        }


    }


    @Override
    protected void onHandleIntent(Intent intent) {
        new ObtenerDesafio(this).execute(prefs.getString("id", null));
    }

    @Override
    public void obtenerDesafio(ArrayList<Desafios> lista) {
        if (lista != null && lista.size() != 0) {
            ArrayList<Desafios> listaConPreguntas = new ArrayList<Desafios>();
            for (int i = 0; i < lista.size(); i++) {
                if (lista.get(i).getQuestions().size() != 0) {
                    listaConPreguntas.add(lista.get(i));
                }
            }
            if (listaConPreguntas.size() > 0) {
                listaDesafios = listaConPreguntas;
                checkear();
            }
        }
    }
}
