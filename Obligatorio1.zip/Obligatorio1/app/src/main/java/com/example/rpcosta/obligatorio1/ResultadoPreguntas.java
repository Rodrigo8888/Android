package com.example.rpcosta.obligatorio1;

import AsyncTask.CerrarDesafio;
import AsyncTask.PreguntaVersus;
import AsyncTask.RegistrarRespuesta;
import AsyncTask.ValidarPregunta;
import DataBase.BaseDatos;
import Interfaces.ValPregunta;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;


public class ResultadoPreguntas extends Activity implements ValPregunta {
    private String url;
    private Button continuar;
    private ImageView image;
    private Boolean tiempo;
    private String idP;
    private String idU;
    private Bitmap icon, icon1, icon2;
    private BaseDatos db;
    private int correctasYo, correctasEl;
    private String versus, challenge;
    private ArrayList<String> lista;
    private Desafios desafio;
    private String id_challenge;
    private ArrayList<Desafios> listaDesafios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultado_preguntas);
        continuar = (Button) findViewById(R.id.button);
        image = (ImageView) findViewById(R.id.imageView);
        Bundle b = getIntent().getExtras();
        correctasYo = 0;
        correctasEl = 0;
        idP = b.getString("idP");
        String idO = b.getString("idO");
        tiempo = b.getBoolean("time");
        idU = b.getString("idUser");
        final String tipo = b.getString("tipo");
        versus = b.getString("versus");
        challenge = b.getString("idChallenge");
        desafio = (Desafios) b.getSerializable("desafio");
        db = new BaseDatos(this);
        listaDesafios = db.listaDesafios();
        for (int i = 0; i < listaDesafios.size(); i++) {
            ArrayList<Questions> listaPreguntas = db.obtenerPreguntas(listaDesafios.get(i));
            listaDesafios.get(i).setQuestions(listaPreguntas);
        }
        if (versus != null) {
            
            if(desafio!=null){
                id_challenge = desafio.getId();
            }
            else{
                id_challenge = challenge;
            }
            for (int i = 0; i < listaDesafios.size(); i++) {
                if (id_challenge.equalsIgnoreCase(listaDesafios.get(i).getId())) {
                    for (int j = 0; j < listaDesafios.get(i).getQuestions().size(); j++) {
                        if (listaDesafios.get(i).getQuestions().get(j).getId_user().equalsIgnoreCase(idU)) {
                            if (listaDesafios.get(i).getQuestions().get(j).getSuccess()) {
                                correctasYo += 1;
                            }
                        } else {
                            if (listaDesafios.get(i).getQuestions().get(j).getSuccess()) {
                                correctasEl += 1;
                            }
                        }
                    }
                }
            }
        }
        lista = new ArrayList<String>();

        if (tiempo) {
            url = "http://ortapipreguntados.herokuapp.com" + "/questions/validate?" + "id_question=" + idP + "&id_option=" + idO;
            new ValidarPregunta(this).execute(url);

        } else {
            if (versus == null) {
                lista.add("0");
                lista.add("0");
                lista.add("false");
                findViewById(R.id.loadingPanel).setVisibility(View.GONE);
                icon2 = decodeSampledBitmapFromResource(this.getResources(), R.drawable.tiempo, 50, 50);
                image.setImageBitmap(icon2);
                new RegistrarRespuesta(this).execute(lista);
            } else {
                if (desafio != null) {
                    Questions q = new Questions();
                    q.setSuccess(false);
                    q.setId_user(idU);
                    q.setId_question(idP);
                    desafio.getQuestions().add(q);
                    db.insertarPreguntasDesafio(desafio);
                    desafio.setQuestions(db.obtenerPreguntas(desafio));
                }
                lista.add(id_challenge);
                lista.add(idU);
                lista.add(idP);
                lista.add("false");
                findViewById(R.id.loadingPanel).setVisibility(View.GONE);
                icon2 = decodeSampledBitmapFromResource(this.getResources(), R.drawable.tiempo, 50, 50);
                image.setImageBitmap(icon2);
                new PreguntaVersus().execute(lista);

            }

        }

        continuar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (correctasYo == 3 && correctasEl < 3) {
                    Intent i = new Intent(ResultadoPreguntas.this, MiPerfil.class);
                    startActivity(i);
                } else {
                    if (correctasEl == 3 && correctasYo < 3) {
                        Intent i = new Intent(ResultadoPreguntas.this, MiPerfil.class);
                        startActivity(i);
                    } else {
                        if (correctasYo == 3 && correctasEl == 3) {
                            Intent i = new Intent(ResultadoPreguntas.this, MiPerfil.class);
                            startActivity(i);
                        } else {
                            if (tipo.equalsIgnoreCase("random")) {
                                if (versus == null) {
                                    Intent i = new Intent(ResultadoPreguntas.this, DesafioIndividual.class);
                                    i.putExtra("idUser", idU);
                                    i.putExtra("tipo", tipo);
                                    startActivity(i);
                                } else {
                                    Intent i = new Intent(ResultadoPreguntas.this, VentanaDesafios.class);
                                    i.putExtra("ids", idU);
                                    startActivity(i);
                                }
                            }
                            if (tipo.equalsIgnoreCase("elegir")) {
                                Intent i = new Intent(ResultadoPreguntas.this, ElegirCategoria.class);
                                i.putExtra("idUser", idU);
                                i.putExtra("tipo", tipo);
                                startActivity(i);
                            }
                        }

                    }

                }

            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.resultado_preguntas, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void refreshDatos(Boolean respuesta) {
        lista.clear();
        findViewById(R.id.loadingPanel).setVisibility(View.GONE);
        icon = decodeSampledBitmapFromResource(this.getResources(), R.drawable.correcto, 50, 50);
        icon1 = decodeSampledBitmapFromResource(this.getResources(), R.drawable.incorrecto, 50, 50);
        if (respuesta) {
            if (versus != null) {
                correctasYo += 1;
                lista.add(id_challenge);
                lista.add(idU);
                lista.add(idP);
                lista.add("true");
                new PreguntaVersus().execute(lista);
                ArrayList<String> listas = new ArrayList<String>();
                listas.add(idP);
                listas.add(idU);
                listas.add("true");
                new RegistrarRespuesta(this).execute(listas);
                if (desafio != null) {
                    Questions q = new Questions();
                    q.setSuccess(true);
                    q.setId_user(idU);
                    q.setId_question(idP);
                    desafio.getQuestions().add(q);
                    db.insertarPreguntasDesafio(desafio);
                    desafio.setQuestions(db.obtenerPreguntas(desafio));
                }
                //controlar en las pares y mayor o igual a 6
                if (((desafio.getQuestions().size() % 2) == 0) && desafio.getQuestions().size() >= 6) {
                    if (correctasYo == 3 && correctasEl < 3) {
                        //gané yo, cerrar desafío
                        icon = decodeSampledBitmapFromResource(this.getResources(), R.drawable.hasganado, 50, 50);
                        image.setImageBitmap(icon);
                        ArrayList<String> lista = new ArrayList<String>();
                        lista.add(id_challenge);
                        lista.add(idU);
                        new CerrarDesafio().execute(lista);
                    } else {
                        if (correctasEl == 3 && correctasYo < 3) {
                            //gano él, cerrar desafío como perdido
                            icon = decodeSampledBitmapFromResource(this.getResources(), R.drawable.hasperdido, 50, 50);
                            image.setImageBitmap(icon);
                            ArrayList<String> lista = new ArrayList<String>();
                            lista.add(id_challenge);
                            if (!desafio.getId_user1().equalsIgnoreCase(idU)) {
                                lista.add(desafio.getId_user1());
                            } else {
                                lista.add(desafio.getId_user2());
                            }
                            new CerrarDesafio().execute(lista);
                        } else {
                            if (correctasYo == 3 && correctasEl == 3) {
                                //empate, cerrar desafío
                                icon = decodeSampledBitmapFromResource(this.getResources(), R.drawable.hasempatado, 50, 50);
                                image.setImageBitmap(icon);
                                ArrayList<String> lista = new ArrayList<String>();
                                lista.add(id_challenge);
                                lista.add("0");
                                new CerrarDesafio().execute(lista);
                            } else {
                                icon = decodeSampledBitmapFromResource(this.getResources(), R.drawable.correcto, 50, 50);
                                image.setImageBitmap(icon);

                            }

                        }
                    }

                } else {
                    icon = decodeSampledBitmapFromResource(this.getResources(), R.drawable.correcto, 50, 50);
                    image.setImageBitmap(icon);

                }
            } else {
                icon = decodeSampledBitmapFromResource(this.getResources(), R.drawable.correcto, 50, 50);
                ArrayList<String> listas = new ArrayList<String>();
                listas.add(idP);
                listas.add(idU);
                listas.add("true");
                new RegistrarRespuesta(this).execute(listas);
                image.setImageBitmap(icon);
            }

        } else {
            if (versus != null) {
                lista.add(id_challenge);
                lista.add(idU);
                lista.add(idP);
                lista.add("false");
                new PreguntaVersus().execute(lista);
                ArrayList<String> listas = new ArrayList<String>();
                listas.add(idP);
                listas.add(idU);
                listas.add("false");
                new RegistrarRespuesta(this).execute(listas);
                if (desafio != null) {
                    Questions q = new Questions();
                    q.setSuccess(false);
                    q.setId_user(idU);
                    q.setId_question(idP);
                    desafio.getQuestions().add(q);
                    db.insertarPreguntasDesafio(desafio);
                    desafio.setQuestions(db.obtenerPreguntas(desafio));
                }
                //controlar en las pares y mayor o igual a 6
                if (((desafio.getQuestions().size() % 2) == 0) && desafio.getQuestions().size() >= 6) {
                    if (correctasYo == 3 && correctasEl < 3) {
                        //gané yo, cerrar desafío
                        icon1 = decodeSampledBitmapFromResource(this.getResources(), R.drawable.hasganado, 50, 50);
                        image.setImageBitmap(icon1);
                        ArrayList<String> lista = new ArrayList<String>();
                        lista.add(id_challenge);
                        lista.add(idU);
                        new CerrarDesafio().execute(lista);
                    } else {
                        if (correctasEl == 3 && correctasYo < 3) {
                            //gano él, cerrar desafío como perdido
                            icon1 = decodeSampledBitmapFromResource(this.getResources(), R.drawable.hasperdido, 50, 50);
                            image.setImageBitmap(icon1);
                            ArrayList<String> lista = new ArrayList<String>();
                            lista.add(id_challenge);
                            if (!desafio.getId_user1().equalsIgnoreCase(idU)) {
                                lista.add(desafio.getId_user1());
                            } else {
                                lista.add(desafio.getId_user2());
                            }
                            new CerrarDesafio().execute(lista);
                        } else {
                            if (correctasYo == 3 && correctasEl == 3) {
                                //empate, cerrar desafío
                                icon1 = decodeSampledBitmapFromResource(this.getResources(), R.drawable.hasempatado, 50, 50);
                                image.setImageBitmap(icon1);
                                ArrayList<String> lista = new ArrayList<String>();
                                lista.add(id_challenge);
                                lista.add("0");
                                new CerrarDesafio().execute(lista);
                            } else {
                                icon1 = decodeSampledBitmapFromResource(this.getResources(), R.drawable.incorrecto, 50, 50);
                                image.setImageBitmap(icon1);

                            }

                        }
                    }

                } else {
                    icon1 = decodeSampledBitmapFromResource(this.getResources(), R.drawable.incorrecto, 50, 50);
                    image.setImageBitmap(icon1);

                }
            } else {
                icon1 = decodeSampledBitmapFromResource(this.getResources(), R.drawable.incorrecto, 50, 50);
                ArrayList<String> listas = new ArrayList<String>();
                listas.add(idP);
                listas.add(idU);
                listas.add("false");
                new RegistrarRespuesta(this).execute(listas);
                image.setImageBitmap(icon1);
            }
        }


    }

    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 6;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            // Calculate the largest inSampleSize value that is a power of 2 and keeps both
            // height and width larger than the requested height and width.
            while ((halfHeight / inSampleSize) > reqHeight
                    && (halfWidth / inSampleSize) > reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    public static Bitmap decodeSampledBitmapFromResource(Resources res, int resId,
                                                         int reqWidth, int reqHeight) {

        // First decode with inJustDecodeBounds=true to check dimensions
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeResource(res, resId, options);

        // Calculate inSampleSize
        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        // Decode bitmap with inSampleSize set
        options.inJustDecodeBounds = false;
        return BitmapFactory.decodeResource(res, resId, options);
    }

    @Override
    public void registroRespuesta(Boolean respuesta) {

    }


    @Override
    public void onBackPressed() {

    }

    @Override
    protected void onStop() {
        super.onStop();
        if(icon!=null){
            icon.recycle();

        }
        if(icon1!=null){
            icon1.recycle();

        }
        if(icon2!=null){
            icon2.recycle();

        }

    }


}
