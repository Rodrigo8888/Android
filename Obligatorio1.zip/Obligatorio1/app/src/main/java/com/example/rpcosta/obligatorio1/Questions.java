package com.example.rpcosta.obligatorio1;

import java.io.Serializable;

/**
 * Created by rpcosta on 8/12/14.
 */
public class Questions implements Serializable {
    Boolean success;
    String id_user;
    String id_question;

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getId_user() {
        return id_user;
    }

    public void setId_user(String id_user) {
        this.id_user = id_user;
    }

    public String getId_question() {
        return id_question;
    }

    public void setId_question(String id_question) {
        this.id_question = id_question;
    }
}
