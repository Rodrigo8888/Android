package com.example.rpcosta.obligatorio1;

import DataBase.BaseDatos;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import com.squareup.picasso.Picasso;


public class ElegirCategoria extends Activity {
    ImageView arte, historia, geografia, deporte, ciencia, entretenimiento, fotoPerfil;
    private BaseDatos db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elegir_categoria);
        arte = (ImageView) findViewById(R.id.imageView);
        historia = (ImageView) findViewById(R.id.imageView2);
        geografia = (ImageView) findViewById(R.id.imageView4);
        deporte = (ImageView) findViewById(R.id.imageView5);
        ciencia = (ImageView) findViewById(R.id.imageView8);
        entretenimiento = (ImageView) findViewById(R.id.imageView6);
        fotoPerfil = (ImageView)findViewById(R.id.imageView10);
        db = new BaseDatos(this);
        String image = db.urlImagen();
        if(!image.equalsIgnoreCase("")){
            fotoPerfil.setBackground(null);
            Picasso.with(ElegirCategoria.this).load(image).into(fotoPerfil);
        }
        Bundle b = getIntent().getExtras();
        final String ides = b.getString("ids");
        final String tipo = b.getString("tipo");
        arte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id_cat = db.idCategoria("Arte y Literatura");
                Intent inte = new Intent(ElegirCategoria.this, Arte.class);
                inte.putExtra("id", id_cat);
                inte.putExtra("idUser",ides);
                inte.putExtra("tipo",tipo);
                startActivity(inte);

            }
        });
        
        historia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id_cat = db.idCategoria("Historia");
                Intent inte = new Intent(ElegirCategoria.this, Historia.class);
                inte.putExtra("id", id_cat);
                inte.putExtra("idUser",ides);
                inte.putExtra("tipo",tipo);
                startActivity(inte); 
            }
        });
        
        deporte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id_cat = db.idCategoria("Deportes");
                Intent inte = new Intent(ElegirCategoria.this, Deporte.class);
                inte.putExtra("id", id_cat);
                inte.putExtra("idUser",ides);
                inte.putExtra("tipo",tipo);
                startActivity(inte);
            }
        });
        
        geografia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id_cat = db.idCategoria("Geografía");
                Intent inte = new Intent(ElegirCategoria.this, Geografia.class);
                inte.putExtra("id", id_cat);
                inte.putExtra("idUser",ides);
                inte.putExtra("tipo",tipo);
                startActivity(inte);
            }
        });
        ciencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id_cat = db.idCategoria("Ciencia y Tecnología");
                Intent inte = new Intent(ElegirCategoria.this, Ciencia.class);
                inte.putExtra("id", id_cat);
                inte.putExtra("idUser",ides);
                inte.putExtra("tipo",tipo);
                startActivity(inte);
            }
        });
         entretenimiento.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String id_cat = db.idCategoria("Entretenimiento");
                 Intent inte = new Intent(ElegirCategoria.this, Entretenimiento.class);
                 inte.putExtra("id", id_cat);
                 inte.putExtra("idUser",ides);
                 inte.putExtra("tipo",tipo);
                 startActivity(inte);
             }
         });
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.elegir_categoria, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent(ElegirCategoria.this,MiPerfil.class);
        startActivity(i);
    }
}
