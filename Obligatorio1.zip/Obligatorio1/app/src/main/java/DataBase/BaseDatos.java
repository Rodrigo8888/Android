package DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.rpcosta.obligatorio1.Categorias;
import com.example.rpcosta.obligatorio1.Desafios;
import com.example.rpcosta.obligatorio1.Questions;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {

    public BaseDatos(Context context) {
        super(context, "DataBase.db", null, 1);


    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        String creaTablaCategoria = "CREATE TABLE LISTACATEGORIA (id INTEGER NOT NULL "
                + "PRIMARY KEY AUTOINCREMENT, nombreCategoria VARCHAR(200),idCat VARCHAR(200)"
                + " NOT NULL)";
        String creaTablaDesafios = "CREATE TABLE DESAFIOS (id INTEGER NOT NULL "
                + "PRIMARY KEY AUTOINCREMENT, idDesafio VARCHAR(200),status VARCHAR(200), winner VARCHAR(200),"
                + "id_user1 VARCHAR(200), id_user2 VARCHAR(200), nombre VARCHAR(200), url VARCHAR(200), mail VARCHAR(200)"
                + " NOT NULL)";
        String creaTablaPreguntas = "CREATE TABLE PREGUNTAS (id INTEGER NOT NULL "
                + "PRIMARY KEY AUTOINCREMENT,idPreg VARCHAR(200),"
                + "idOption VARCHAR(200)"
                + " NOT NULL)";
        String creaTablaImagenes = "CREATE TABLE IMAGENES (id INTEGER NOT NULL "
                + "PRIMARY KEY AUTOINCREMENT,url VARCHAR(200)"
                + " NOT NULL)";
        String creaTablaPreguntasDesafios = "CREATE TABLE PREGUNTASDESAFIOS (id INTEGER NOT NULL "
                + "PRIMARY KEY AUTOINCREMENT,idDesafio VARCHAR(200), success VARCHAR(200), id_user VARCHAR(200), id_question VARCHAR(200)"
                + " NOT NULL)";


        db.execSQL(creaTablaCategoria);
        db.execSQL(creaTablaPreguntas);
        db.execSQL(creaTablaDesafios);
        db.execSQL(creaTablaImagenes);
        db.execSQL(creaTablaPreguntasDesafios);

    }

    public ArrayList<Categorias> listaCategorias() {
        boolean finish = false;
        ArrayList<Categorias> datos = new ArrayList<Categorias>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("Select nombreCategoria,idCat from LISTACATEGORIA", null);
        while (c.moveToNext() && !finish) {
            Categorias cat = new Categorias();
            cat.setNombre(c.getString(0));
            cat.setId(c.getString(1));
            datos.add(cat);
        }
        return datos;
    }

    public ArrayList<Desafios> listaDesafios() {
        ArrayList<Desafios> datos = new ArrayList<Desafios>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("Select idDesafio,status, winner, id_user1, id_user2, nombre, url, mail from DESAFIOS", null);
        while (c.moveToNext()) {
            Desafios des = new Desafios();´
            des.setId(c.getString(0));
            des.setStatus(c.getString(1));
            des.setWinner(c.getString(2));
            des.setId_user1(c.getString(3));
            des.setId_user2(c.getString(4));
            des.setName(c.getString(5));
            des.setUrl(c.getString(6));
            des.setMail(c.getString(7));
            datos.add(des);
        }
        return datos;
    }

    public String idCategoria(String nombre) {
        boolean finish = false;
        String datos = "";
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("Select nombreCategoria,idCat from LISTACATEGORIA", null);
        while (c.moveToNext() && !finish) {
            if (nombre.equalsIgnoreCase(c.getString(0))) {
                datos = c.getString(1);
                finish = true;
            }
        }
        return datos;
    }

    public String urlImagen() {
        String datos = "";
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("Select url from IMAGENES", null);
        while (c.moveToNext()) {
            datos = c.getString(0);
        }
        return datos;
    }

    public int insertarPreguntasDesafio(Desafios desafio) {
        int idPreguntaDesafio = 0;
        SQLiteDatabase db = getWritableDatabase();
        SQLiteDatabase d = getReadableDatabase();
        ContentValues values = new ContentValues();
        ArrayList<Questions> lista = obtenerPreguntas(desafio);
        for (int i = lista.size(); i < desafio.getQuestions().size(); i++) {
            Cursor c = d.rawQuery("Select idDesafio, success, id_user, id_question from PREGUNTASDESAFIOS where idDesafio = " + "'" + desafio.getId() + "' and id_question = '" + desafio.getQuestions().get(i).getId_question() + "'", null);
            if (!c.moveToFirst()) {
                values.put("idDesafio", desafio.getId());
                values.put("success", String.valueOf(desafio.getQuestions().get(i).getSuccess()));
                values.put("id_user", desafio.getQuestions().get(i).getId_user());
                values.put("id_question", desafio.getQuestions().get(i).getId_question());
                idPreguntaDesafio = (int) db.insert("PREGUNTASDESAFIOS", null, values);
            }

        }
        d.close();
        db.close();
        return idPreguntaDesafio;
    }

    public ArrayList<Questions> obtenerPreguntas(Desafios desafios) {
        ArrayList<Questions> lista = new ArrayList<Questions>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("Select idDesafio, success, id_user, id_question from PREGUNTASDESAFIOS where idDesafio = " + "'" + desafios.getId() + "'", null);
        if (c.moveToFirst()) {
            do {
                Questions q = new Questions();
                q.setId_question(c.getString(3));
                q.setId_user(c.getString(2));
                if (c.getString(1).equalsIgnoreCase("true")) {
                    q.setSuccess(true);
                } else {
                    q.setSuccess(false);
                }
                lista.add(q);

            } while (c.moveToNext());

        }
        return lista;
    }

    public int insertarCategoria(String nombre, String id) {
        int idCategoria = 0;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("nombreCategoria", nombre);
        values.put("idCat", id);
        idCategoria = (int) db.insert("LISTACATEGORIA", null, values);
        db.close();
        return idCategoria;
    }

    public int insertarImagen(String url) {
        int idImagen = 0;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("url", url);
        idImagen = (int) db.insert("IMAGENES", null, values);
        db.close();
        return idImagen;
    }

    public int insertarDesafios(Desafios desafio) {
        int idDesafio = 0;
        Boolean repetdo = false;
        SQLiteDatabase db = getWritableDatabase();
        SQLiteDatabase d = getReadableDatabase();
        Cursor c = d.rawQuery("Select idDesafio, status, id from DESAFIOS where idDesafio = '" + desafio.getId() + "'", null);
        if (c.moveToNext()) {
            if (!c.getString(1).equalsIgnoreCase(desafio.getStatus())) {
                ContentValues values = new ContentValues();
                values.put("idDesafio", desafio.getId());
                values.put("status", desafio.getStatus());
                values.put("winner", desafio.getWinner());
                values.put("id_user1", desafio.getId_user1());
                values.put("id_user2", desafio.getId_user2());
                values.put("nombre", desafio.getName());
                values.put("url", desafio.getUrl());
                values.put("mail", desafio.getMail());
                
                idDesafio = (int) db.update("DESAFIOS", values, "id = '"+c.getString(2)+"'", null);
                db.close();
            }

        } else {
            ContentValues values = new ContentValues();
            values.put("idDesafio", desafio.getId());
            values.put("status", desafio.getStatus());
            values.put("winner", desafio.getWinner());
            values.put("id_user1", desafio.getId_user1());
            values.put("id_user2", desafio.getId_user2());
            values.put("nombre", desafio.getName());
            values.put("url", desafio.getUrl());
            values.put("mail", desafio.getMail());
            idDesafio = (int) db.insert("DESAFIOS", null, values);
            db.close();
        }
        return idDesafio;
    }

    public int insertarPregunta(String idPreg, String idOption) {
        int idPregunta = 0;
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("idPreg", idPreg);
        values.put("idOption", idOption);
        idPregunta = (int) db.insert("PREGUNTAS", null, values);
        db.close();
        return idPregunta;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("drop table if exists datos");
        onCreate(db);

    }


}
