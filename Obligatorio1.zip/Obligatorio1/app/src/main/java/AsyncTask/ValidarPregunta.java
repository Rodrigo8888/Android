package AsyncTask;

import android.os.AsyncTask;
import android.util.Log;
import Interfaces.ValPregunta;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

/**
 * Created by rpcosta on 7/11/14.
 */
public class ValidarPregunta extends AsyncTask<String,String,Boolean> {
    ValPregunta val;
    Boolean resp;

    public ValidarPregunta(ValPregunta ctx) {
        val = ctx;

    }

    @Override
    protected void onPostExecute(Boolean aBoolean) {
        super.onPostExecute(aBoolean);
        val.refreshDatos(aBoolean);
    }

    @Override
    protected Boolean doInBackground(String... params) {
        try {
            URL url = new URL(params[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            InputStream in = new BufferedInputStream(connection.getInputStream());
            JSONObject json = new JSONObject(getResponseText(in));
            Log.v("aver",json.toString());
            Boolean respuesta = json.getBoolean("success");
            if(respuesta){
               resp = true;
            }
            else{
                resp=false;
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return resp;
    }

    private String getResponseText(InputStream inStream) {
        return new Scanner(inStream).useDelimiter("\\A").next();
    }

}
