package AsyncTask;

import Interfaces.ObtenerListaCategorias;
import android.os.AsyncTask;
import com.example.rpcosta.obligatorio1.Categorias;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by rpcosta on 7/12/14.
 */
public class ObtenerCategorias extends AsyncTask<String, String, ArrayList<Categorias>> {
    private Boolean respuesta;
    private ObtenerListaCategorias ctx;
    private ArrayList<Categorias> listaCat;

    public ObtenerCategorias(ObtenerListaCategorias ctx) {
        this.ctx=ctx;
    }

    @Override
    protected void onPostExecute(ArrayList<Categorias> aBoolean) {
        super.onPostExecute(aBoolean);
        ctx.obteneRespuesta(aBoolean);
    }

    @Override
    protected ArrayList<Categorias> doInBackground(String... params) {
        try {
            URL url = new URL("http://ortapipreguntados.herokuapp.com/categories/");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            InputStream in = new BufferedInputStream(connection.getInputStream());
            JSONObject json = new JSONObject(getResponseText(in));
            respuesta = json.getBoolean("success");
            listaCat = new ArrayList<Categorias>();
            if(respuesta){
                JSONArray datos = json.getJSONArray("categories");
                for(int i=0;i<datos.length();i++){
                    JSONObject Obj = (JSONObject) datos.get(i);
                    Categorias c = new Categorias();
                    c.setId(Obj.getString("_id"));
                    c.setNombre(Obj.getString("name"));
                    listaCat.add(c);
                }
                
                
            }
        } catch (MalformedURLException e1) {
            e1.printStackTrace();
        } catch (JSONException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }

        return listaCat;
    }

    private String getResponseText(InputStream inStream) {
        return new Scanner(inStream).useDelimiter("\\A").next();
    }

}
