package AsyncTask;

import android.os.AsyncTask;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;

/**
 * Created by rpcosta on 10/12/14.
 */
public class PreguntaVersus extends AsyncTask<ArrayList<String>,String,Boolean> {
    private Boolean respuesta;
    private String url;


    @Override
    protected Boolean doInBackground(ArrayList<String>... params) {
        try {
            url ="http://ortapipreguntados.herokuapp.com/challenges/responseQuestion?";
            String request = url;
            URL url = new URL(request);
            String urlParameters = "id_challenge=" + params[0].get(0) + "&id_user=" + params[0].get(1)+"&id_question="+params[0].get(2) + "&success="+ params[0].get(3)+"&date="+Calendar.getInstance().getTime();
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("charset", "utf-8");
            connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
            connection.setUseCaches(false);
            DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            InputStreamReader in = new InputStreamReader(connection.getInputStream());
            JSONObject json = new JSONObject(getResponseText(in));
            boolean response = (Boolean) json.getBoolean("success");
            if (response) {
                respuesta = true;
            } else {
                respuesta = false;
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return respuesta;
    }
    private String getResponseText(InputStreamReader inStream) {
        return new Scanner(inStream).useDelimiter("\\A").next();
    }
}
