package AsyncTask;

import Interfaces.BuscarJugadorInterface;
import android.os.AsyncTask;
import com.example.rpcosta.obligatorio1.Jugador;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by rpcosta on 13/12/14.
 */
public class BuscarJugador extends AsyncTask<String, String, ArrayList<Jugador>> {
    private ArrayList<Jugador> lista;
    private BuscarJugadorInterface contexto;

    public BuscarJugador(BuscarJugadorInterface ctx) {
        this.contexto = ctx;
    }


    @Override
    protected void onPostExecute(ArrayList<Jugador> aBoolean) {
        super.onPostExecute(aBoolean);
        contexto.buscarJugador(aBoolean);
        
    }

    @Override
    protected ArrayList<Jugador> doInBackground(String... params) {
        lista = new ArrayList<Jugador>();
        URL url = null;
        try {
            url = new URL("http://ortapipreguntados.herokuapp.com/users/search/?" + "name=" + params[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            InputStream in = new BufferedInputStream(connection.getInputStream());
            JSONObject json = new JSONObject(getResponseText(in));
            Boolean respuesta = (Boolean) json.getBoolean("success");
            if(respuesta){
                JSONArray users = json.getJSONArray("users");
                for(int i=0; i<users.length();i++){
                    JSONObject user = (JSONObject) users.get(i);
                    Jugador j = new Jugador();
                    j.setUrl(user.getString("image"));
                    j.setNombre(user.getString("name"));
                    j.setMail(user.getString("mail"));
                    j.setId(user.getString("_id"));
                    lista.add(j);
                }
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return lista;
    }

    private String getResponseText(InputStream inStream) {
        return new Scanner(inStream).useDelimiter("\\A").next();
    }


}
