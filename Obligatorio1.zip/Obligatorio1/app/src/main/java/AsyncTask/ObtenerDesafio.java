package AsyncTask;

import Interfaces.Desafio;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import com.example.rpcosta.obligatorio1.Desafios;
import com.example.rpcosta.obligatorio1.Questions;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by rpcosta on 6/12/14.
 */
public class ObtenerDesafio extends AsyncTask<String, String, ArrayList<Desafios>> {
    private Desafio ctx;
    private ArrayList<Desafios> lista;
    private SharedPreferences prefs;


    public ObtenerDesafio(Desafio ctx) {
        this.ctx = ctx;
    }

    @Override
    protected void onPostExecute(ArrayList<Desafios> lista) {
        super.onPostExecute(lista);
        ctx.obtenerDesafio(lista);
    }

    @Override
    protected ArrayList<Desafios> doInBackground(String... params) {
        try {
            URL url = new URL("http://ortapipreguntados.herokuapp.com/challenges/get?" + "id_user=" + params[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            InputStream in = new BufferedInputStream(connection.getInputStream());
            JSONObject json = new JSONObject(getResponseText(in));
            boolean response = (Boolean) json.getBoolean("success");
            if (response) {
                JSONArray datos = json.getJSONArray("challenges");
                lista = new ArrayList<Desafios>();
                for (int i = 0; i < datos.length(); i++) {
                    ArrayList<Questions> listaQ = new ArrayList<Questions>();
                    Desafios desafio = new Desafios();
                    JSONObject Obj = (JSONObject) datos.get(i);
                    JSONArray Qst = Obj.getJSONArray("questions");
                    JSONArray users = Obj.getJSONArray("users");
                    for(int t =0; t<users.length();t++){
                        JSONObject usuarios = (JSONObject) users.get(t);
                        if(!params[0].equalsIgnoreCase(usuarios.getString("_id"))){
                            desafio.setName(usuarios.getString("name"));
                            desafio.setUrl(usuarios.getString("image"));
                            desafio.setMail(usuarios.getString("mail"));
                        }
                    }
                    for (int j = 0; j < Qst.length(); j++) {
                        Questions questions = new Questions();
                        JSONObject preguntas = (JSONObject) Qst.get(j);
                        questions.setSuccess(preguntas.getBoolean("success"));
                        questions.setId_question(preguntas.getString("id_question"));
                        questions.setId_user(preguntas.getString("id_user"));
                        listaQ.add(questions);
                    }
                    desafio.setId(Obj.getString("_id"));
                    desafio.setId_user1(Obj.getString("id_user1"));
                     desafio.setId_user2(Obj.getString("id_user2"));
                    desafio.setStatus(Obj.getString("status"));
                    desafio.setWinner(Obj.getString("winner"));
                    desafio.setQuestions(listaQ);
                    lista.add(desafio);
                }

            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return lista;
    }

    private String getResponseText(InputStream inStream) {
        return new Scanner(inStream).useDelimiter("\\A").next();
    }

}
