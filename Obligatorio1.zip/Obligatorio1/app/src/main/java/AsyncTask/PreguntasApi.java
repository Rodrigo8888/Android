package AsyncTask;

import android.os.AsyncTask;
import com.example.rpcosta.obligatorio1.EstructuraPreguntas;
import Interfaces.APIPreguntas;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Created by rpcosta on 6/11/14.
 */
public class PreguntasApi extends AsyncTask<String ,String,EstructuraPreguntas> {
    private APIPreguntas ctx;
    private EstructuraPreguntas preg;
    public PreguntasApi(APIPreguntas api) {
        ctx=api;
    }

    @Override
    protected void onPostExecute(EstructuraPreguntas estructuraPreguntas) {
        super.onPostExecute(estructuraPreguntas);
        ctx.refreshPreguntas(estructuraPreguntas);
    }

    @Override
    protected EstructuraPreguntas doInBackground(String... params) {

        try {
            URL url = new URL(params[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            InputStream in = new BufferedInputStream(connection.getInputStream());
            JSONObject json = new JSONObject(getResponseText(in));
            JSONObject datos = json.getJSONObject("question");
            Boolean respuesta = json.getBoolean("success");
            ArrayList<String>op = new ArrayList<String>();
            ArrayList<String> ids = new ArrayList<String>();
            if(respuesta){
                preg = new EstructuraPreguntas();
                String question = datos.getString("question");
                String id = datos.getString("_id");
                JSONArray pregunta = datos.getJSONArray("options");
                preg.setPreguntas(question);
                preg.setIdPregunta(id);
                for(int i=0;i<pregunta.length();i++) {
                    JSONObject dato = (JSONObject) pregunta.get(i);
                    op.add(dato.getString("option"));
                    ids.add(dato.getString("id"));
                }
                preg.setOpciones(op);
                preg.setIdOption(ids);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return preg;
    }

    private String getResponseText(InputStream inStream) {
        return new Scanner(inStream).useDelimiter("\\A").next();
    }
}
