package AsyncTask;

import Interfaces.CrearDesafioInterface;
import android.os.AsyncTask;
import com.example.rpcosta.obligatorio1.Desafios;
import com.example.rpcosta.obligatorio1.Questions;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Scanner;


/**
 * Created by rpcosta on 14/12/14.
 */
public class CrearDesafio extends AsyncTask<ArrayList<String>, String, Desafios> {
    private String url;
    private CrearDesafioInterface ctx;
    private Desafios desafio;

    public CrearDesafio(CrearDesafioInterface ctx) {
        this.ctx = ctx;
    }

    @Override
    protected void onPostExecute(Desafios desafios) {
        super.onPostExecute(desafios);
        ctx.crearDesafio(desafios);
    }

    @Override
    protected Desafios doInBackground(ArrayList<String>... params) {

        try {
            url = "http://ortapipreguntados.herokuapp.com/challenges/new?";
            String request = url;
            URL url = new URL(request);
            String urlParameters = "id_user1=" + params[0].get(0) + "&id_user2=" + params[0].get(1) + "&date=" + Calendar.getInstance().getTime();
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setDoInput(true);
            connection.setInstanceFollowRedirects(false);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("charset", "utf-8");
            connection.setRequestProperty("Content-Length", "" + Integer.toString(urlParameters.getBytes().length));
            connection.setUseCaches(false);
            DataOutputStream wr = new DataOutputStream(connection.getOutputStream());
            wr.writeBytes(urlParameters);
            wr.flush();
            InputStreamReader in = new InputStreamReader(connection.getInputStream());
            JSONObject json = new JSONObject(getResponseText(in));
            Boolean response = (Boolean) json.getBoolean("success");
            if (response) {
                ArrayList<Questions> listaQ = new ArrayList<Questions>();
                JSONObject Obj = json.getJSONObject("challenge");
                desafio = new Desafios();
                JSONArray Qst = Obj.getJSONArray("questions");
                for (int j = 0; j < Qst.length(); j++) {
                    Questions questions = new Questions();
                    JSONObject preguntas = (JSONObject) Qst.get(j);
                    questions.setSuccess(preguntas.getBoolean("success"));
                    questions.setId_question(preguntas.getString("id_question"));
                    questions.setId_user(preguntas.getString("id_user"));
                    listaQ.add(questions);
                }
                desafio.setId(Obj.getString("_id"));
                desafio.setId_user1(Obj.getString("id_user1"));
                desafio.setId_user2(Obj.getString("id_user2"));
                desafio.setStatus(Obj.getString("status"));
                desafio.setWinner(Obj.getString("winner"));
                desafio.setQuestions(listaQ);
            }

        } catch (MalformedURLException e1) {
            e1.printStackTrace();
        } catch (ProtocolException e1) {
            e1.printStackTrace();
        } catch (JSONException e1) {
            e1.printStackTrace();
        } catch (IOException e1) {
            e1.printStackTrace();
        }


        return desafio;
    }

    private String getResponseText(InputStreamReader inStream) {
        return new Scanner(inStream).useDelimiter("\\A").next();
    }
}
