package Interfaces;

/**
 * Created by rpcosta on 21/10/14.
 */
public interface RegUsuario {

    public void result(Boolean results, String id);

}
