package Interfaces;

import com.example.rpcosta.obligatorio1.Jugador;

import java.util.ArrayList;

/**
 * Created by rpcosta on 13/12/14.
 */
public interface BuscarJugadorInterface {
    public void buscarJugador(ArrayList<Jugador> listaJugadores);
}

