package Interfaces;

import com.example.rpcosta.obligatorio1.ObjetoEstadisticas;

import java.util.ArrayList;

/**
 * Created by rpcosta on 24/10/14.
 */
public interface Estadistica {
    public void refreshEstadistics(ArrayList<ObjetoEstadisticas> lista);
}
