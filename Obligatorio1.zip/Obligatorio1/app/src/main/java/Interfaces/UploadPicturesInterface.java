package Interfaces;

/**
 * Created by rpcosta on 15/12/14.
 */
public interface UploadPicturesInterface {
    public void respuesta(String respuesta); 
}
