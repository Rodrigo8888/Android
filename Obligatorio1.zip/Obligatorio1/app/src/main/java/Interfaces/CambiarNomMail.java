package Interfaces;

/**
 * Created by rpcosta on 23/10/14.
 */
public interface CambiarNomMail {
    public void resultado(Boolean done);
}
