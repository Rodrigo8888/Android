package Interfaces;

import com.example.rpcosta.obligatorio1.Desafios;

import java.util.ArrayList;

/**
 * Created by rpcosta on 6/12/14.
 */
public interface Desafio {
    public void obtenerDesafio(ArrayList<Desafios> lista);
}
