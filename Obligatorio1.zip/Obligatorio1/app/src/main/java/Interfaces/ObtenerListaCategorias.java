package Interfaces;

import com.example.rpcosta.obligatorio1.Categorias;

import java.util.ArrayList;

/**
 * Created by rpcosta on 7/12/14.
 */
public interface ObtenerListaCategorias {
    public void obteneRespuesta(ArrayList<Categorias> respuesta);
}
