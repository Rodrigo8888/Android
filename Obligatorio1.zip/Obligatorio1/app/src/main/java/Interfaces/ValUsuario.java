package Interfaces;

/**
 * Created by rpcosta on 21/10/14.
 */
public interface ValUsuario {
    public void validacion(Boolean correcto, String ide, String name, String mail);

}
