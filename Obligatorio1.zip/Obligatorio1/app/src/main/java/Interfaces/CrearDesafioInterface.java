package Interfaces;

import com.example.rpcosta.obligatorio1.Desafios;

/**
 * Created by rpcosta on 14/12/14.
 */
public interface CrearDesafioInterface {
    public void crearDesafio(Desafios desafio);
}
