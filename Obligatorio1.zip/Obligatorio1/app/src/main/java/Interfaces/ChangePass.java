package Interfaces;

/**
 * Created by rpcosta on 22/10/14.
 */
public interface ChangePass {
    public void result(Boolean results);
}
