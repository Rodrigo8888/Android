package Interfaces;

/**
 * Created by rpcosta on 7/11/14.
 */
public interface ValPregunta {

    public void refreshDatos(Boolean respuesta);
    public void registroRespuesta(Boolean respuesta);
}
