package Interfaces;

import com.example.rpcosta.obligatorio1.EstructuraPreguntas;

/**
 * Created by rpcosta on 6/11/14.
 */
public interface APIPreguntas {
    public void refreshPreguntas(EstructuraPreguntas pregunta);

}
